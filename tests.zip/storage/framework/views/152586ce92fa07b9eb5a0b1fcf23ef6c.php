<?php $__env->startSection('konten'); ?>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center mb-4" >Form Input Nilai</div>
                    <div class="card-body">
                        <form enctype="multipart/form-data" data-toggle="validator" method="POST" id="forminputnilai" action="<?php echo e(url('/inputnilai')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Nama Peserta</label>
                                <select class="custom-select" id="iduser" name="iduser" >
                                    <option value="">Nama Peserta</option>
                                    <?php $__currentLoopData = $datapeserta; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($data->id); ?>><?php echo e($data->name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            <div class="form-group">
                                <label>Nama Aktifitas</label>
                                <select class="custom-select" id="idmateri" name="idmateri" >
                                    <option value="">Pilih Aktifitas</option>
                                    <?php $__currentLoopData = $datamateri; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e(json_encode($data)); ?>"><?php echo e($data->materiname); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                            </div>

                            <div class="form-group">
                                <label for="name">Nilai</label>
                                <input id="nilai" type="number" class="form-control" name="nilai" required autofocus>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\evindo\resources\views/pengajar/inputnilai.blade.php ENDPATH**/ ?>