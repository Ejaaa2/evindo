<?php $__env->startSection('konten'); ?>
<section class="simple-cta">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title text-center mb-4">Tabel Nilai</h3>
                    </div>
                    <form method="POST" action="<?php echo e(url('statussiswa')); ?>">
                        <?php echo csrf_field(); ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Lengkap</th>
                                <th>Email</th>
                                <th>Role</th>
                                <th>Tanggal Daftar</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->email); ?></td>
                                <td><?php echo e($item->role); ?></td>
                                <td><?php echo e($item->created_at); ?></td>
                                <td><input type="checkbox" name="listpeserta[]" value="<?php echo e($item->id); ?>"></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                        <div class="form-group">
                            <label>Nama Course</label>
                            <select class="custom-select" id="idcourse" name="idcourse" required >
                                <option value="">Pilih Course</option>
                                <?php $__currentLoopData = $datacourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value=<?php echo e($data->id); ?>><?php echo e($data->coursename); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <td><button type="submit" class="btn btn-primary float-right">Submit</button></td>
                      </table>
                      </form>
                        <div class="card-footer clearfix">
                        <ul class="pagination pagination-sm m-0 float-right">
                        <li class="page-item"><a class="page-link" href="#">«</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">»</a></li>
                        </ul>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\evindo\resources\views/helpdesk/terimasiswa.blade.php ENDPATH**/ ?>