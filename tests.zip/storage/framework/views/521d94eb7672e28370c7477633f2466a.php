<?php $__env->startSection('konten'); ?>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header text-center mb-4" >Form Tambah Materi</div>

                    <div class="card-body">
                        <form enctype="multipart/form-data" data-toggle="validator" method="POST" id="forminputmateri" action="<?php echo e(url('/inputmateri')); ?>">
                            <?php echo csrf_field(); ?>

                            <div class="form-group">
                                <label>Nama Course</label>
                                <select class="custom-select" id="idcourse" name="idcourse" >
                                    <option value="">Pilih Course</option>
                                    <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value=<?php echo e($data->id); ?>><?php echo e($data->coursename); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="name">Name Materi</label>
                                <input id="namamateri" type="text" class="form-control" name="namamateri" required autofocus>
                            </div>

                            <div class="form-group">
                                <label>Status Materi</label>
                                <select class="custom-select" id="status" name="status" >
                                    <option value="">Pilih Status</option>
                                        <option value="Materi">Materi</option>
                                        <option value="Tugas">Tugas</option>
                                        <option value="Quiz">Quiz</option>
                                        <option value="Ujian">Ujian</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="deskripsi">Deskripsi</label>
                                <textarea id="deskripsi" name="deskripsi" class="form-control" rows="3" placeholder="Enter ..."></textarea>
                            </div>

                            <div class="form-group">
                                <label for="link">Link Materi</label>
                                <input id="materi" type="text" class="form-control" name="materi" required>
                            </div>

                            <div class="form-group">
                                <button type="submit" class="btn btn-primary">Submit</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\evindo\resources\views/helpdesk/tambahmateri.blade.php ENDPATH**/ ?>