    <!-- Bootstrap core CSS -->
    <link href="<?php echo e(asset('eduwell/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="<?php echo e(asset('eduwell/assets/css/fontawesome.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('eduwell/assets/css/templatemo-eduwell-style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('eduwell/assets/css/owl.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('eduwell/assets/css/lightbox.csss')); ?>">
<?php /**PATH C:\Laravel\evindo\resources\views/layout/part/link.blade.php ENDPATH**/ ?>