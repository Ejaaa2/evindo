<?php $__env->startSection('konten'); ?>
<section>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title text-center mb-4">Tabel Nilai</h3>
                    </div>
                    <table class="table table-bordered text-center">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Lengkap</th>
                                <th>Status</th>
                                <th>Materi</th>
                                <th>Rata" Nilai Tugas 25%</th>
                                <th>Nilai Quiz 35%</th>
                                <th>Nilai Ujian 40%</th>
                                <th>Total Nilai</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <th><?php echo e($item->id); ?></th>
                                <td><?php echo e($item->name); ?></td>
                                <td><?php echo e($item->role); ?></td>
                                <td><?php echo e($item->materiname); ?></td>
                                <td><?php echo e($item->nilaiTugas); ?></td>
                                <td><?php echo e($item->nilaiQuiz); ?></td>
                                <td><?php echo e($item->nilaiUjian); ?></td>
                                <td><?php echo e($item->nilaiTugas * 0.25 + $item->nilaiQuiz * 0.35 + $item->nilaiUjian * 0.4); ?></td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                      </table>
                        <div class="card-footer clearfix">
                        <ul class="pagination pagination-sm m-0 float-right">
                        <li class="page-item"><a class="page-link" href="#">«</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">»</a></li>

                        <a>Jika ada kesalahan input nilai silahkan pengajar input ulang nilai.</a>
                        </ul>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\evindo\resources\views/helpdesk/nilaipeserta.blade.php ENDPATH**/ ?>