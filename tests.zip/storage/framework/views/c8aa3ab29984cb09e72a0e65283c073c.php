<?php $__env->startSection('konten'); ?>
<section class="simple-cta">
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-8">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title text-center mb-4">Tabel Nilai</h3>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Lengkap</th>
                                <th>Status</th>
                                <th>Materi</th>
                                <th>Course</th>
                                <th>Nilai Tugas</th>
                                <th>Nilai Quiz</th>
                                <th>Nilai Ujian</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <tr>
                                <th>1</th>
                                <td>Hart Hagerty</td>
                                <td>Siswa</td>
                                <td>Pengembangan Diri</td>
                                <td>Dasar-dasar ekspor</td>
                                <td>80</td>
                                <td>90</td>
                                <td>65</td>
                                <td><button class="btn btn-primary">Edit</button></td>
                            </tr>
                        </tbody>
                      </table>
                        <div class="card-footer clearfix">
                        <ul class="pagination pagination-sm m-0 float-right">
                        <li class="page-item"><a class="page-link" href="#">«</a></li>
                        <li class="page-item"><a class="page-link" href="#">1</a></li>
                        <li class="page-item"><a class="page-link" href="#">»</a></li>
                        </ul>
                        </div>
                </div>
            </div>
        </div>
    </div>
</section>

<?php $__env->stopSection(); ?>

<?php echo $__env->make("layout.main", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Laravel\evindo\resources\views/nilaipeserta.blade.php ENDPATH**/ ?>