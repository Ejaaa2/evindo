    <!-- Bootstrap core CSS -->
    <link href="{{asset('eduwell/vendor/bootstrap/css/bootstrap.min.css')}}" rel="stylesheet">


    <!-- Additional CSS Files -->
    <link rel="stylesheet" href="{{asset('eduwell/assets/css/fontawesome.css')}}">
    <link rel="stylesheet" href="{{asset('eduwell/assets/css/templatemo-eduwell-style.css')}}">
    <link rel="stylesheet" href="{{asset('eduwell/assets/css/owl.css')}}">
    <link rel="stylesheet" href="{{asset('eduwell/assets/css/lightbox.csss')}}">
